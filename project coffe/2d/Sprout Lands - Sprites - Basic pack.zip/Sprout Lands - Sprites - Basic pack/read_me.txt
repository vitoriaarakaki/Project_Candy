Heyo! Thanks for downloading the Sprout Lands asset pack. -Made by: Cup Nooble 

This asset pack is the start of a series of different asset packs, so let me know if there's any specific sprites you'd like in future packs.

License - Free Basic Pack
  - You can modify the assets.
  - You can not redistribute or resale, even if modified.
  - You can only use these assets in non-commercial projects. 
( If you want to make something commercial with these sprites contact me)

Follow Sprout Lands on Twitter for future updates :
https://twitter.com/Sprout_Lands

If you enjoy this then leave a rating and comment. It helps to support this project! :D
